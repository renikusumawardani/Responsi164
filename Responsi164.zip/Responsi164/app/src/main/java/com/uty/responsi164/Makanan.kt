package com.uty.responsi164

class Makanan (val title:String, val desc:String, val photo:Int )