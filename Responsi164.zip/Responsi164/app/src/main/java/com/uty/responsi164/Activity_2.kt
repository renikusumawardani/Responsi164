package com.uty.responsi164

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ListView
import android.widget.Toast
import android.content.Intent

class Activity_2 : AppCompatActivity() {
    lateinit var listView : ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        listView = findViewById(R.id.listView)
        var list = mutableListOf<Makanan>()

        list.add(Makanan("Gudeg", "Makanan Khas Jogja", R.drawable.gudeg))
        list.add(Makanan("Cenil", "Makanan Khas Jogja", R.drawable.cenil))
        list.add(Makanan("Bakpia", "Makanan Khas Jogja", R.drawable.bakpia))
        list.add(Makanan("Krecek", "Makanan Khas Jogja", R.drawable.krecek))
        list.add(Makanan("Oseng-Oseng Mercon", "Makanan Khas Jogja", R.drawable.osengmercon))
        list.add(Makanan("Sate Kelinci", "Makanan Khas Jogja", R.drawable.satekelinci))
        list.add(Makanan("Soto", "Makanan Khas Jogja", R.drawable.soto))
        list.add(Makanan("Tempe", "Makanan Khas Jogja", R.drawable.tempe))
        list.add(Makanan("Tiwul", "Makanan Khas Jogja", R.drawable.tiwul))

        listView.adapter = Adapter(this, R.layout.list_mkn, list)

        listView.setOnItemClickListener { parent:AdapterView<*>, view:View, position:Int, id:Long ->
            if (position == 0 ){
                Toast.makeText(this@Activity_2, "Anda Memilih Gudeg", Toast.LENGTH_LONG).show()
            }
            if (position == 1 ){
                Toast.makeText(this@Activity_2, "Anda Memilih Cenil", Toast.LENGTH_LONG).show()
            }
            if (position == 2 ){
                Toast.makeText(this@Activity_2, "Anda Memilih Bakpia", Toast.LENGTH_LONG).show()
            }
            if (position == 3 ){
                Toast.makeText(this@Activity_2, "Anda Memilih Krecek", Toast.LENGTH_LONG).show()
            }
            if (position == 4 ){
                Toast.makeText(this@Activity_2, "Anda Memilih Oseng-Oseng Mercon", Toast.LENGTH_LONG).show()
            }
            if (position == 4 ){
                Toast.makeText(this@Activity_2, "Anda Memilih Sate Kelinci", Toast.LENGTH_LONG).show()
            }
            if (position == 4 ){
                Toast.makeText(this@Activity_2, "Anda Memilih Soto", Toast.LENGTH_LONG).show()
            }
            if (position == 4 ){
                Toast.makeText(this@Activity_2, "Anda Memilih Tempe", Toast.LENGTH_LONG).show()
            }
            if (position == 4 ){
                Toast.makeText(this@Activity_2, "Anda Memilih Tiwul", Toast.LENGTH_LONG).show()
            }
        }
    }
}